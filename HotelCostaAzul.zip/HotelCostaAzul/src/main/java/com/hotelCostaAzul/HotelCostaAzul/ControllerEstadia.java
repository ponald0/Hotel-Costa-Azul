package com.hotelCostaAzul.HotelCostaAzul;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
@Controller
public class ControllerEstadia {
    @GetMapping("/Estadia")
    public String estadiaPage() {
        return "estadia"; /* Spring Boot busca 'estadia.html' en 'src/main/resources/templates'*/
    }

}
