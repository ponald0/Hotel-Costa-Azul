package com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.controlador;

import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Modelo.Usuario;
import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Servicio.UsuarioServicio;
import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.dto.UsuarioRegitroDTO;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/registro")
public class RegistroUsuarioControlador {

    private UsuarioServicio usuarioServicio;

    public RegistroUsuarioControlador(UsuarioServicio usuarioServicio) {
        this.usuarioServicio = usuarioServicio;
    }

    @ModelAttribute("usuario")
    public UsuarioRegitroDTO retonarUsuarioRegistroDTO(){
        return new UsuarioRegitroDTO();
    }

    @GetMapping
    public String mostrarFomularioDeRegistro(){
        return "registro";
    }

    @PostMapping
    public String registrarCuentaDeUsuario(@ModelAttribute("usuario") UsuarioRegitroDTO usuarioRegitroDTO){
        Usuario usuarioGuardado = usuarioServicio.guardar(usuarioRegitroDTO);

        if (usuarioGuardado == null) {
            return "redirect:/registro?error=email_existente"; // Redirige con un parámetro de error
        }

        return "redirect:/registro?exito=true";
    }

}
