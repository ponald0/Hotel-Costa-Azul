package com.hotelCostaAzul.HotelCostaAzul;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelCostaAzulApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelCostaAzulApplication.class, args);
	}

}
