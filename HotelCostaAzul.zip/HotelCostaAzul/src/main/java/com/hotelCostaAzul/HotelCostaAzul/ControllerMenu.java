package com.hotelCostaAzul.HotelCostaAzul;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class ControllerMenu {

    @GetMapping("/Menu")
    public String MenuPage() {
        return "Menu"; /* Spring Boot busca 'Menu.html' en 'src/main/resources/templates'*/
    }

    @GetMapping("/Cerrar")
    public ModelAndView logout(RedirectAttributes redirectAttributes) {
        ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        HttpSession session = attr.getRequest().getSession(false);

        if (session != null) {
            session.invalidate();
        }
        redirectAttributes.addFlashAttribute("message", "se ah cerrado sesion.");
        return new ModelAndView("redirect:/");
    }
}




