package com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.controlador;

import com.hotelCostaAzul.HotelCostaAzul.SignUpandLogin.Servicio.UsuarioServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ControllerInicioSesion {

    private final UsuarioServicio usuarioServicio;

    @Autowired
    public ControllerInicioSesion(UsuarioServicio usuarioServicio) {
        this.usuarioServicio = usuarioServicio;
    }

    @GetMapping("/login")
    public String mostrarLogin(Model model) {
        return "index";
    }

    @PostMapping("/login")
    public ModelAndView iniciarSesion(@RequestParam String email, @RequestParam String password) {
        if (usuarioServicio.autenticar(email, password)) {

            return new ModelAndView("redirect:/principal");
        } else {

            ModelAndView modelAndView = new ModelAndView("index");
            modelAndView.addObject("error", "Usuario o contraseña inválidos");
            return modelAndView;
        }
    }
}
