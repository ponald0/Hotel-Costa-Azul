package com.hotelCostaAzul.HotelCostaAzul;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
@Controller
public class ControllerHabitaciones {

    @GetMapping("/Habitacion")
    public String habitacionPage() {
        return "habitacion"; /* Spring Boot busca 'habitacion.html' en 'src/main/resources/templates'*/
    }

}
